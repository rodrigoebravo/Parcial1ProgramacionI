#include "LinkedList.h"

int parser_parseCompras(char* fileName, LinkedList* lista)
{

    return 1; // OK
}

