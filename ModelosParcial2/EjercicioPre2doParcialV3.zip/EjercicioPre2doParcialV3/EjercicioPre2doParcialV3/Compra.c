#include "Compra.h"

void com_calcularMonto(void* p)
{

}
